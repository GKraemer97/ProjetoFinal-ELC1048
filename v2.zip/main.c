#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <string.h>

#include "server.h"



int main(int argc, char **argv){
    pthread_t t2;//, t1;
    serverParam servidor, *servidor1;
    sigset_t alarm_sig;
	int i, rc;
    
    sigemptyset (&alarm_sig);
	for (i = SIGRTMIN; i <= SIGRTMAX; i++)
	    sigaddset (&alarm_sig, i);
	sigprocmask (SIG_BLOCK, &alarm_sig, NULL);

    servidor.argc = argc;
    servidor.argv = argv;

    servidor1 = &servidor;
    
    //cria a thread do servidor
    rc = pthread_create(&t2, NULL, server, (void*)servidor1);
    if(rc){
        printf("Erro criando a thread servidor!\n");
        return 0;
    }else{
        printf("Thread servidor criada!\n");
    }

    //pthread_join(t1, NULL);
    pthread_join(t2, NULL);



    return 0;
}
