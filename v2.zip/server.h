#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>

#include "rastreador.h"

#define TOTAL 5

//struct utilizada para passar os parâmetros de inicialização do server através da pthread_create
typedef struct serverParam {
    int argc;
    char **argv;
} serverParam;

pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

struct nodo {
    int newsockfd;
};

struct nodo nodo[5];

void *cliente(void *arg) {
    pthread_t t1;
    long cid = (long)arg;
    int i, n, rc;
    char buffer[256];
    while (1) {
        bzero(buffer,sizeof(buffer));
        n = read(nodo[cid].newsockfd,buffer,50);
        printf("Recebeu: %s - %lu\n", buffer,strlen(buffer));
        if (n <= 0) {
            printf("Erro lendo do socket id %lu!\n", cid);
            close(nodo[cid].newsockfd);
            nodo[cid].newsockfd = -1;

            pthread_exit(NULL);
        }else{ // teste
            if(strcmp(buffer, "rastreamento\n") == 0){
                //função que ativa/desativa o rastreamento
                switchTracing();    
            }
            else if(strcmp(buffer, "controle\n") == 0){
                if(estado_gps == 0){
                    printf("Rastreador desativado. Controle de velocidade indisponivel!\n");
                }else{
                    //função que ativa/desativa o controle de velocidade
                    speedControl();
                }
            }
            else if(strcmp(buffer, "localizacao\n") == 0){
                if(estado_gps == 0){
                    printf("Rastreador desativado. Restricao de localizacao indisponivel!\n");
                }else{
                    //função que ativa/desativa a restrição de localização
                    restrictLocation();
                }
            }
            else if(strcmp(buffer, "distancia\n") == 0){
                if(estado_gps == 0){
                    printf("Rastreador desativado. Distancia percorrida indisponivel!\n");
                }else{
                    //função que obtém a distância percorrida desde o início do rastreamento
                    printf("Distância percorrida:\t%f\n", getDistance());
                }
            }
            else if(strcmp(buffer, "velocidade\n")){
                if(estado_gps == 0){
                    printf("Rastreador desativado. Velocidade media atual indisponivel");
                }else{
                    //função que obtém a velocidade média atual
                    printf("Velocidade media atual:\t%f\n", getSpeed());
                }
            }else{
                printf("Comando indisponivel!\n");
            }
        }
        // fim teste
        // MUTEX LOCK - GERAL
        pthread_mutex_lock(&m);
        for (i = 0;i < TOTAL; i++) {
            if ((i != cid) && (nodo[i].newsockfd != -1)) {
                n = write(nodo[i].newsockfd,buffer,50);
                if (n <= 0) {
                    printf("Erro escrevendo no socket id %i!\n", i);
//                    close(nodo[i].newsockfd);
//                    nodo[i].newsockfd = -1;
                }
            }
        }
        pthread_mutex_unlock(&m);
        // MUTEX UNLOCK - GERAL
    }
}

void *server(void* arg) {
    //teste
    struct serverParam *servidor1 = (serverParam*)arg;
    int argc = servidor1->argc;
    char **argv = servidor1->argv;
    //

    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;
    int sockfd, portno;
    pthread_t t;
    long i;

    if (argc < 2) {
        printf("Erro, porta nao definida!\n");
        printf("./SOFTWARE PORTA");
        exit(1);
    }
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        printf("Erro abrindo o socket!\n");
        exit(1);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) {
        printf("Erro fazendo bind!\n");
        exit(1);
    }
    listen(sockfd,5);

    for (i = 0; i < TOTAL; i++) {
      nodo[i].newsockfd = -1;
    }
    while (1) {
        for (i = 0; i < TOTAL; i++) {
          if (nodo[i].newsockfd == -1) break;
        }
        nodo[i].newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr,&clilen);
        // MUTEX LOCK - GERAL
        pthread_mutex_lock(&m);
        if (nodo[i].newsockfd < 0) {
            printf("Erro no accept!\n");
            exit(1);
        }
        pthread_create(&t, NULL, cliente, (void *)i);
        pthread_mutex_unlock(&m);
        // MUTEX UNLOCK - GERAL
    }
    //    close(sockfd);
    return 0; 
}
