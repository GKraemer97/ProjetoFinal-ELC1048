#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "gps.h"
// Variáveis globais
int state = 0; // indica qual estado a lampada está
int timer_on = 0; // tempo que a lampada está acesa
void* lampada(void *arg){
	
	
}

void LigarLampada(int tempo){
	timer_on = tempo + timer_on;
	state = 1;
}
void DesligarLampada(int tempo){
	timer_on = timer_on - tempo;
	state = 0;
}
int VerificaEstado(){
	int t;
	t = state;
	if(t == 1){
	   return 1;
	}else{
		return 0;
	}
}
int VerificaTempo(){
	int t = 0;
	t = timer_on;
	
	return timer_on;
}
int SetaIntervalo(int tempoHoras){
	return 0;
}
