#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#include "server.h"


int main(int argc, char **argv){
    pthread_t t1,t2,t3;
    serverParam servidor, *servidor_1;
    int t;
    

    servidor.argc = argc;
    servidor.argv = argv;

    servidor_1 = &servidor;

    
    //Criação da thread do Servidor
    t = pthread_create(&t1, NULL, server, (void*)servidor_1);
    if(t){
        printf("Erro criando a thread servidor!\n");
        return 0;
    }else{
        printf("Thread servidor criada!\n");
    }
	
	// Criação da thread lampada
	t = pthread_create(&t2, NULL, lampada, NULL);
    if(t){
        printf("Erro criando a thread LAMPADA!\n");
        return 0;
    }else{
        printf("Thread LAMPADA criada!\n");
    }
	t = pthread_create(&t3, NULL, gps, NULL);
    if(t){
        printf("Erro criando a thread GPS!\n");
        return 0;
    }else{
        printf("Thread GPS criada!\n");
    }
	
	

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
	pthread_join(t3, NULL);



    return 0;
}
